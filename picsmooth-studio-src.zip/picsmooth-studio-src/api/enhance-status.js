// GET /api/enhance-status — backend capability probe + prediction polling.
//   /api/enhance-status            -> { configured: true|false }
//   /api/enhance-status?id=<pid>   -> { status, output, error }
module.exports = async (req, res) => {
  const token = process.env.REPLICATE_API_TOKEN;
  if (!token) {
    return res.status(200).json({ configured: false });
  }
  const { id } = req.query || {};
  if (!id) {
    return res.status(200).json({ configured: true });
  }
  try {
    const r = await fetch(`https://api.replicate.com/v1/predictions/${encodeURIComponent(id)}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await r.json();
    if (!r.ok) {
      return res.status(502).json({ error: "Replicate lookup failed", detail: data.detail || r.status });
    }
    return res.status(200).json({ status: data.status, output: data.output || null, error: data.error || null });
  } catch (err) {
    return res.status(502).json({ error: "Could not reach Replicate", detail: String(err && err.message || err) });
  }
};
