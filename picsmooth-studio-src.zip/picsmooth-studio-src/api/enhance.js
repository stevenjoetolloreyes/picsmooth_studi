// POST /api/enhance — creates a Replicate Real-ESRGAN prediction.
// Env: REPLICATE_API_TOKEN (required), REPLICATE_MODEL (optional, default nightmareai/real-esrgan)
module.exports = async (req, res) => {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }
  const token = process.env.REPLICATE_API_TOKEN;
  if (!token) {
    return res.status(503).json({ error: "AI backend not configured", code: "NO_API_KEY" });
  }
  let body = req.body;
  if (typeof body === "string") {
    try { body = JSON.parse(body); } catch { return res.status(400).json({ error: "Invalid JSON body" }); }
  }
  const { image, scale } = body || {};
  if (!image || typeof image !== "string" || !image.startsWith("data:image/")) {
    return res.status(400).json({ error: "No image provided (expected data URL)" });
  }
  if (image.length > 8 * 1024 * 1024) {
    return res.status(413).json({ error: "Image too large (max ~8MB data URL)" });
  }
  const model = process.env.REPLICATE_MODEL || "nightmareai/real-esrgan";
  const s = Math.min(10, Math.max(1, parseInt(scale, 10) || 4));
  try {
    const r = await fetch(`https://api.replicate.com/v1/models/${model}/predictions`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        Prefer: "wait",
      },
      body: JSON.stringify({ input: { image, scale: s, face_enhance: true } }),
    });
    const data = await r.json();
    if (!r.ok) {
      return res.status(502).json({ error: "Replicate rejected the request", detail: data.detail || data.title || r.status });
    }
    return res.status(200).json({ id: data.id, status: data.status });
  } catch (err) {
    return res.status(502).json({ error: "Could not reach Replicate", detail: String(err && err.message || err) });
  }
};
