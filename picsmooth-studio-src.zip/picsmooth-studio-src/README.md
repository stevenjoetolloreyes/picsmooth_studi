# PicSmooth Studio

Wink Studio-style AI photo enhancer web app. Upload a photo, pick HD / 4K / 16K,
get a smoothed, upscaled result with a before/after compare slider.

## Project structure

```
picsmooth-studio/
├── index.html          # app shell (Home / Templates / Me tabs, editor)
├── css/
│   └── styles.css      # all styling (dark mobile-first theme)
├── js/
│   └── app.js          # all frontend logic
├── assets/
│   └── img-*.jpg       # sample photos + template thumbnails
├── api/
│   ├── enhance.js        # POST /api/enhance  -> creates a Replicate prediction
│   └── enhance-status.js # GET /api/enhance-status -> polls prediction / probes config
├── vercel.json
└── README.md
```

## How enhancement works

1. The app first checks `GET /api/enhance-status`.
2. **If the AI backend is configured** (Replicate token set), the photo is sent to
   the cloud: `POST /api/enhance` creates a Real-ESRGAN prediction, the frontend
   polls `GET /api/enhance-status?id=...` until it succeeds, then shows the
   AI-enhanced result.
3. **If the backend is NOT configured**, the app automatically falls back to the
   built-in on-device enhancement (upscale + denoise + color fix + sharpening).
   Everything still works — no dead buttons.

## Deploy (GitHub × Vercel)

1. Push this folder to a GitHub repository.
2. In Vercel: **Add New → Project → Import** the repository. Framework preset:
   **Other**. No build command needed.
3. Deploy. The site works immediately with on-device enhancement.

## Enable the AI backend (optional, paid)

The cloud enhancer uses [Replicate](https://replicate.com) (Real-ESRGAN model).
Replicate charges per image — **you** pay on your own Replicate account.

1. Create an account at replicate.com and copy an **API token**
   (dashboard → API tokens).
2. In Vercel: Project → **Settings → Environment Variables**, add:
   - `REPLICATE_API_TOKEN` = your token
   - `REPLICATE_MODEL` (optional) = e.g. `nightmareai/real-esrgan`
3. **Redeploy** the project so the functions pick up the new variables.
4. Open the site and enhance a photo — progress will show "Uploading to AI…".

Never commit your API token to the repository. It lives only in Vercel's
environment variables.

## Notes

- Drafts, favorites and coins are per-session (in-memory) in this version.
- Sample photos in `assets/` are placeholders — swap them with your own.
