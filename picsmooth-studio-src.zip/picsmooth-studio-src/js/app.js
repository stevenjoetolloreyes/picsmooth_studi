"use strict";
      const $ = (s, r) => (r || document).querySelector(s);
      const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
      const tick = () => new Promise(r => setTimeout(r, 10));

      /* ---------------- icons ---------------- */
      const P = (inner) => '<svg width="27" height="27" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' + inner + '</svg>';
      const ICONS = {
        smile: P('<circle cx="12" cy="12" r="8.4"/><circle cx="9.1" cy="10.2" r=".5" fill="currentColor"/><circle cx="14.9" cy="10.2" r=".5" fill="currentColor"/><path d="M8.6 14.4c.95 1.35 2.05 2 3.4 2s2.45-.65 3.4-2"/>'),
        cube: P('<path d="M12 3.2 19.5 7.4v9.2L12 20.8l-7.5-4.2V7.4L12 3.2Z"/><path d="M12 12 19.5 7.4M12 12v8.8M12 12 4.5 7.4"/>'),
        collage: P('<rect x="3.6" y="3.6" width="7.4" height="16.8" rx="1.8"/><rect x="13" y="3.6" width="7.4" height="7.4" rx="1.8"/><rect x="13" y="13" width="7.4" height="7.4" rx="1.8"/>'),
        face: P('<circle cx="12" cy="12" r="8.4"/><circle cx="9.1" cy="10.4" r=".5" fill="currentColor"/><circle cx="14.9" cy="10.4" r=".5" fill="currentColor"/><path d="M8.8 14.6c.9 1.2 1.9 1.8 3.2 1.8s2.3-.6 3.2-1.8"/><path d="M4.6 10.2C5.2 6 8.3 3.6 12 3.6c1.9 0 3.6.7 4.9 1.9"/>'),
        body: P('<circle cx="12" cy="4.9" r="2.2"/><path d="M8.2 20.6v-3.4c0-2.9-.4-4.4-.4-6 0-2 1.9-3.4 4.2-3.4s4.2 1.4 4.2 3.4c0 1.6-.4 3.1-.4 6v3.4"/><path d="M7.9 14.2h8.2"/>'),
        makeup: P('<path d="M10.2 3.4 13.8 6.8v3.7h-3.6V3.4Z"/><rect x="9.1" y="10.5" width="5.8" height="3.4" rx="1"/><path d="M9.6 13.9h4.8v5.4a1.7 1.7 0 0 1-1.7 1.7h-1.4a1.7 1.7 0 0 1-1.7-1.7v-5.4Z"/>'),
        wand: P('<path d="m5.5 20.5 8.7-8.7"/><path d="M16.8 3.4l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8.8-2Z"/><path d="M20.4 12.4l.55 1.4 1.4.55-1.4.55-.55 1.4-.55-1.4-1.4-.55 1.4-.55.55-1.4Z"/><path d="M9.5 3.8l.5 1.25 1.25.5-1.25.5-.5 1.25-.5-1.25-1.25-.5L9 5.05l.5-1.25Z"/>'),
        flame: P('<path d="M12 3.4c.9 3-1.5 4.7-2.8 6.3C7.9 11.2 7.1 12.8 7.1 14.5a4.9 4.9 0 0 0 9.8 0c0-1.5-.6-2.8-1.4-4-.4 1-1 1.8-2 2.2.4-3.1-.6-6.5-1.5-9.3Z"/>'),
        eraser: P('<path d="m6 15.8 7.9-7.9a2.05 2.05 0 0 1 2.9 0l1.9 1.9a2.05 2.05 0 0 1 0 2.9l-5.2 5.2H8.9a2.05 2.05 0 0 1-1.5-.6L6 16.4a2.05 2.05 0 0 1 0-.6Z"/><path d="M7.5 20.5h12.5"/>'),
        phone: P('<rect x="6.2" y="2.8" width="11.6" height="18.4" rx="2.4"/><path d="M10.2 18.6h3.6"/>'),
        grid: P('<rect x="4" y="4" width="7" height="7" rx="2"/><rect x="13" y="4" width="7" height="7" rx="2"/><rect x="4" y="13" width="7" height="7" rx="2"/><rect x="13" y="13" width="7" height="7" rx="2"/>'),
        star: '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 3.6l2.5 5.3 5.8.7-4.3 4 1.1 5.7L12 16.5l-5.1 2.8L8 13.6 3.7 9.6l5.8-.7L12 3.6Z"/></svg>',
        chevR: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="m9 5 7 7-7 7"/></svg>'
      };

      /* ---------------- tools ---------------- */
      const TOOLS = [
        { id: "quality", name: "Quality Enhancer", icon: "smile", badge: "hot", desc: "Denoise, sharpen and fix color in one tap", preset: { sat: 1.08, con: 1.07, bri: 1.01, sharp: .55, smooth: .35 } },
        { id: "smart", name: "Smart Enhance", icon: "cube", badge: "pro", desc: "Automatic color, contrast and brightness balance", preset: { sat: 1.18, con: 1.14, bri: 1.03, sharp: .4, smooth: .25 } },
        { id: "superres", name: "Super Resolution", icon: "4k", desc: "Upscale to HD, 4K or 16K with detail sharpening", preset: { sat: 1.05, con: 1.05, bri: 1, sharp: .8, smooth: .2 } },
        { id: "collage", name: "Collage", icon: "collage", badge: "hot", desc: "Combine 2–4 photos into one clean layout", screen: "screen-collage" },
        { id: "face", name: "Face", icon: "face", desc: "Skin smoothing that keeps natural detail", preset: { sat: 1.06, con: 1.03, bri: 1.03, sharp: .3, smooth: .65 }, smoothSlider: true },
        { id: "body", name: "Body", icon: "body", desc: "A gentle slimming warp for portraits", mode: "body" },
        { id: "makeup", name: "Makeup", icon: "makeup", desc: "Warm glow, richer color, soft finish", preset: { sat: 1.24, con: 1.08, bri: 1.04, sharp: .35, smooth: .5 } },
        { id: "retouch", name: "AI Retouch", icon: "wand", desc: "The full retouch recipe: smooth, sharpen, glow", preset: { sat: 1.14, con: 1.1, bri: 1.03, sharp: .5, smooth: .55 } },
        { id: "trending", name: "Trending", icon: "flame", badge: "new", desc: "See the template looks everyone is using", tab: "templates" },
        { id: "removal", name: "AI Removal", icon: "eraser", desc: "Tap spots and small objects to patch them away", mode: "removal" },
        { id: "wallpaper", name: "Live Wallpaper", icon: "phone", desc: "Turn a photo into a 3-second motion clip", mode: "wallpaper" },
        { id: "alltools", name: "All Tools", icon: "grid", desc: "Browse every tool in the studio", screen: "screen-alltools" }
      ];
      const toolById = (id) => TOOLS.find(t => t.id === id);

      function toolIconHTML(t, size) {
        if (t.icon === "4k") return '<span class="mini4k">4K</span>';
        return ICONS[t.icon];
      }
      function badgeHTML(t) {
        if (!t.badge) return "";
        const label = t.badge === "hot" ? "Hot" : t.badge === "new" ? "New" : "PRO";
        return '<span class="badge ' + t.badge + '">' + label + "</span>";
      }

      function renderTools() {
        const grid = $("#toolsGrid");
        grid.innerHTML = TOOLS.map(t =>
          '<button class="tool tap" data-tool="' + t.id + '" data-name="' + t.name.toLowerCase() + '">' +
            '<span class="ic">' + toolIconHTML(t) + badgeHTML(t) + "</span>" +
            '<span class="lbl">' + t.name + "</span>" +
          "</button>"
        ).join("") + '<p class="no-results" id="toolNoResults" hidden>No tools match your search.</p>';
      }
      function renderAllTools() {
        $("#allToolsList").innerHTML = TOOLS.filter(t => t.id !== "alltools").map(t =>
          '<button class="tap" data-tool="' + t.id + '">' +
            '<span class="tic">' + toolIconHTML(t) + badgeHTML(t) + "</span>" +
            "<span><b>" + t.name + "</b><span>" + t.desc + '</span></span>' +
            '<span class="chev">' + ICONS.chevR + "</span>" +
          "</button>"
        ).join("");
      }

      /* ---------------- templates ---------------- */
      const TPLS = [
        { id: "minivlog", name: "Mini Vlog", img: "assets/img-08.jpg", cats: ["vlog", "daily", "trending"], uses: "67.4K uses", tool: "smart", tag: "Mini<br/>Vlog",
          preset: { sat: 1.1, con: 1.05, bri: 1.05, sharp: .35, smooth: .4 } },
        { id: "concert", name: "Fan Cam Night", img: "assets/img-01.jpg", cats: ["trending", "vlog"], uses: "21.7K uses", tool: "retouch", tag: "Fan Cam<br/>Night",
          preset: { sat: 1.3, con: 1.16, bri: 1.02, sharp: .55, smooth: .3 } },
        { id: "travel", name: "Vigan Day Trip", img: "assets/img-05.jpg", cats: ["travel"], uses: "8.9K uses", tool: "smart", tag: "Vigan<br/>Day Trip",
          preset: { sat: 1.22, con: 1.1, bri: 1.03, sharp: .5, smooth: .25 } },
        { id: "food", name: "Fiesta Table", img: "assets/img-10.jpg", cats: ["food"], uses: "4.1K uses", tool: "smart", tag: "Fiesta<br/>Table",
          preset: { sat: 1.32, con: 1.1, bri: 1.02, sharp: .5, smooth: .15 } },
        { id: "arcade", name: "Arcade Neon", img: "assets/img-04.jpg", cats: ["movie", "trending"], uses: "3.3K uses", tool: "quality", tag: "Arcade<br/>Neon",
          preset: { sat: 1.26, con: 1.13, bri: 1.01, sharp: .6, smooth: .2 } },
        { id: "autumn", name: "Autumn Maple", img: "assets/img-03.jpg", cats: ["trending", "travel", "album"], uses: "2.2K uses", tool: "retouch", tag: "Autumn<br/>Maple",
          preset: { sat: 1.2, con: 1.08, bri: 1.04, sharp: .4, smooth: .45 } },
        { id: "samsung", name: "Mall Day", img: "assets/img-02.jpg", cats: ["daily"], uses: "932 uses", tool: "quality", tag: "Mall<br/>Day",
          preset: { sat: 1.1, con: 1.09, bri: 1.04, sharp: .65, smooth: .3 } },
        { id: "laoag", name: "Laoag Day Out", img: "assets/img-09.jpg", cats: ["anniversary", "travel", "daily"], uses: "289 uses", tool: "quality", tag: "Laoag<br/>Day Out",
          preset: { sat: 1.14, con: 1.08, bri: 1.02, sharp: .55, smooth: .3 } },
        { id: "garden", name: "Garden Glow", img: "assets/img-07.jpg", cats: ["daily", "trending", "album"], uses: "136 uses", tool: "face", tag: "Garden<br/>Glow",
          preset: { sat: 1.16, con: 1.05, bri: 1.06, sharp: .3, smooth: .6 } }
      ];
      const CHIPS = [
        { id: "favorites", label: "Favorites" }, { id: "trending", label: "Trending" },
        { id: "daily", label: "Daily" }, { id: "travel", label: "Travel" },
        { id: "vlog", label: "Vlog" }, { id: "movie", label: "Movie" },
        { id: "album", label: "Album" }, { id: "food", label: "Food" },
        { id: "anniversary", label: "Anniversary" }
      ];
      const favs = new Set();
      let activeChip = "trending";

      function renderChips() {
        $("#tplChips").innerHTML = CHIPS.map(c =>
          '<button data-chip="' + c.id + '"' + (c.id === activeChip ? ' class="on"' : "") + ">" + c.label + "</button>"
        ).join("");
      }
      function renderTpls() {
        const q = ($("#tplSearch").value || "").trim().toLowerCase();
        const list = TPLS.filter(t => {
          const chipOK = activeChip === "favorites" ? favs.has(t.id) : t.cats.includes(activeChip);
          const qOK = !q || t.name.toLowerCase().includes(q) || t.cats.some(c => c.includes(q));
          return chipOK && qOK;
        });
        $("#tplGrid").innerHTML = list.map(t =>
          '<div class="tpl">' +
            '<button class="thumb tap" data-template="' + t.id + '">' +
              '<img src="' + t.img + '" alt="' + t.name + ' template" loading="lazy" />' +
              '<span class="tag">' + t.tag + "</span>" +
            "</button>" +
            '<div class="meta">' +
              '<button class="starbtn tap' + (favs.has(t.id) ? " faved" : "") + '" data-fav="' + t.id + '" aria-label="Favorite ' + t.name + '">' + ICONS.star + "</button>" +
              '<span class="uses">' + t.uses + "</span>" +
            "</div>" +
          "</div>"
        ).join("");
        $("#tplEmpty").hidden = list.length > 0;
        if (activeChip === "favorites" && favs.size === 0) {
          $("#tplEmpty").hidden = false;
          $("#tplEmpty").textContent = "No favorites yet — tap the star on any template to keep it here.";
        } else {
          $("#tplEmpty").textContent = "No templates match. Try another word or category.";
        }
      }

      /* ---------------- navigation ---------------- */
      const VIEWS = { home: "#view-home", templates: "#view-templates", me: "#view-me" };
      function switchTab(name) {
        Object.entries(VIEWS).forEach(([k, sel]) => { $(sel).hidden = k !== name; });
        $$(".tabbar button").forEach(b => b.classList.toggle("on", b.dataset.tab === name));
        window.scrollTo({ top: 0 });
      }
      function openScreen(id) { $("#" + id).hidden = false; }
      function closeScreen(el) { const s = el.closest(".screen"); if (s) s.hidden = true; }

      let toastTimer = null;
      function toast(msg) {
        const t = $("#toast");
        t.textContent = msg;
        t.classList.add("show");
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => t.classList.remove("show"), 2600);
      }

      /* ---------------- drafts ---------------- */
      const drafts = [];
      let draftSeq = 0, currentDraftId = null;
      function fmtSize(b) {
        if (!b && b !== 0) return "";
        return b > 1048576 ? (b / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(b / 1024)) + " KB";
      }
      function renderDrafts() {
        const n = drafts.length;
        $("#draftCount").textContent = n;
        $("#draftEmpty").hidden = n > 0;
        $("#loginDraftInfo").textContent = "You have " + n + " draft" + (n === 1 ? "" : "s") + " saved in this session. Drafts live in this browser tab session — download your favorites to keep them for good.";
        $("#cloudDraftInfo").textContent = n + " draft" + (n === 1 ? "" : "s") + " in this session. Anything you save as a draft appears under Me › Drafts.";
        $("#aboutCounts").textContent = "You currently have " + n + " draft" + (n === 1 ? "" : "s") + " and " + favs.size + " favorite template" + (favs.size === 1 ? "" : "s") + ".";
        $("#draftGrid").innerHTML = drafts.map(d =>
          '<button class="draft tap" data-draft="' + d.id + '">' +
            '<img src="' + d.thumb + '" alt="' + d.name + '" />' +
            '<span class="dmeta"><b>' + d.name + "</b><span>" + d.info + "</span></span>" +
          "</button>"
        ).join("");
      }
      function makeThumb(sourceCanvasOrImg, w, h) {
        const c = document.createElement("canvas");
        const tw = 264, th = Math.max(60, Math.round(tw * h / w));
        c.width = tw; c.height = th;
        c.getContext("2d").drawImage(sourceCanvasOrImg, 0, 0, tw, th);
        return c.toDataURL("image/jpeg", .72);
      }
      function addDraft(name, blob, kind, thumb, info) {
        drafts.unshift({ id: ++draftSeq, name, blob, kind, thumb, info });
        renderDrafts();
      }
      function downloadBlob(blob, filename) {
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      }

      /* ---------------- editor ---------------- */
      const ED = {
        tool: null, mode: "enhance", preset: null, label: "",
        img: null, srcURL: "", srcName: "", resultBlob: null, resultURL: "",
        resultKind: "image", res: "4k", strength: 1, brush: 0.06,
        spots: [], busy: false, coins: 0
      };
      const spotLayer = $("#spotLayer");
      spotLayer.style.cssText = "position:absolute;inset:0;pointer-events:none;";
      let wallVideo = null;

      function openEditor(toolId, opts) {
        opts = opts || {};
        const tool = toolById(toolId);
        if (!tool) return;
        if (tool.screen) { openScreen(tool.screen); return; }
        if (tool.tab) { switchTab(tool.tab); return; }
        ED.tool = tool;
        ED.mode = tool.mode || "enhance";
        ED.preset = opts.preset || tool.preset || { sat: 1.08, con: 1.07, bri: 1.01, sharp: .5, smooth: .35 };
        ED.label = opts.label || tool.name;
        $("#editorTitle").textContent = opts.title || tool.name;
        $("#editorFreeNote").textContent = opts.note || "";
        $("#ctlEnhance").hidden = ED.mode !== "enhance";
        $("#ctlBody").hidden = ED.mode !== "body";
        $("#ctlRemoval").hidden = ED.mode !== "removal";
        $("#ctlWallpaper").hidden = ED.mode !== "wallpaper";
        $("#smoothCtl").hidden = !(ED.mode === "enhance" && tool.smoothSlider);
        if (tool.smoothSlider) { $("#smoothRange").value = Math.round(ED.preset.smooth * 100); $("#smoothVal").textContent = Math.round(ED.preset.smooth * 100) + "%"; }
        $("#enhanceHint").hidden = ED.mode !== "enhance";
        $("#actionBtn").textContent =
          ED.mode === "body" ? "Apply Slim" :
          ED.mode === "removal" ? "Erase Spots" :
          ED.mode === "wallpaper" ? "Create Live Wallpaper" : "Enhance Photo";
        openScreen("screen-editor");
        if (opts.loadURL) loadImageFromURL(opts.loadURL, opts.loadName || "sample-photo.jpg");
      }

      function showEditorError(msg) {
        const e = $("#errBox");
        e.textContent = msg;
        e.hidden = false;
      }
      function clearResult() {
        ED.resultBlob = null; ED.resultKind = "image";
        if (ED.resultURL) { URL.revokeObjectURL(ED.resultURL); ED.resultURL = ""; }
        $("#beforeLayer").hidden = true;
        $("#lblAfter").hidden = true; $("#lblBefore").hidden = true;
        $("#cmpDivider").hidden = true; $("#cmpHandle").hidden = true;
        $("#resultBar").hidden = true; $("#outInfo").hidden = true;
        $("#resetBtn").hidden = true; $("#progBox").hidden = true;
        $("#errBox").hidden = true;
        ED.spots = []; spotLayer.innerHTML = "";
        if (wallVideo) { wallVideo.hidden = true; wallVideo.removeAttribute("src"); wallVideo.load(); }
        $("#draftBtn").textContent = "Save Draft";
      }
      function setLoadedImage(img, url, name) {
        ED.img = img; ED.srcURL = url; ED.srcName = name;
        clearResult();
        $("#editorEmpty").hidden = true;
        $("#editorMain").hidden = false;
        $("#baseImg").src = url;
        $("#fileName").textContent = name;
        $("#fileDims").textContent = img.naturalWidth + " × " + img.naturalHeight;
        updateActionState();
      }
      function loadImageFromURL(url, name) {
        const img = new Image();
        img.onload = () => setLoadedImage(img, url, name);
        img.onerror = () => toast("Could not load that photo.");
        img.src = url;
      }
      function loadImageFile(file) {
        if (!file) return;
        if (!/^image\/(jpeg|png|webp)$/.test(file.type)) {
          toast("That file is not a JPG, PNG or WebP photo.");
          if (!$("#editorMain").hidden) showEditorError("Unsupported format — please use a JPG, PNG or WebP photo (max 10MB).");
          return;
        }
        if (file.size > 10 * 1024 * 1024) {
          toast("Photo is too big — 10MB max.");
          if (!$("#editorMain").hidden) showEditorError("That photo is over 10MB. Try a smaller export of it.");
          return;
        }
        const url = URL.createObjectURL(file);
        const img = new Image();
        img.onload = () => setLoadedImage(img, url, file.name);
        img.onerror = () => toast("Could not read that photo.");
        img.src = url;
      }
      function updateActionState() {
        const b = $("#actionBtn");
        if (ED.mode === "removal") b.disabled = ED.busy || ED.spots.length === 0;
        else b.disabled = ED.busy || !ED.img;
      }
      function setProg(pct, step, sub) {
        $("#progBox").hidden = false;
        $("#progBar").style.width = pct + "%";
        if (step) $("#progStep").textContent = step;
        if (sub) $("#progSub").textContent = sub;
      }
      function finishResult(blob, kind, infoText, thumbSource, thumbW, thumbH) {
        ED.resultBlob = blob; ED.resultKind = kind;
        if (ED.resultURL) URL.revokeObjectURL(ED.resultURL);
        ED.resultURL = URL.createObjectURL(blob);
        if (kind === "image") {
          $("#beforeImg").src = ED.srcURL;
          $("#baseImg").src = ED.resultURL;
          $("#beforeLayer").hidden = false;
          $("#lblAfter").hidden = false; $("#lblBefore").hidden = false;
          $("#cmpDivider").hidden = false; $("#cmpHandle").hidden = false;
          setCompare(50);
          if (wallVideo) wallVideo.hidden = true;
        } else {
          if (!wallVideo) {
            wallVideo = document.createElement("video");
            wallVideo.className = "wallout";
            wallVideo.setAttribute("controls", ""); wallVideo.setAttribute("loop", "");
            wallVideo.setAttribute("autoplay", ""); wallVideo.setAttribute("muted", "");
            wallVideo.setAttribute("playsinline", "");
            $("#compareBox").after(wallVideo);
          }
          wallVideo.src = ED.resultURL;
          wallVideo.hidden = false;
          wallVideo.play().catch(() => {});
        }
        $("#progBox").hidden = true;
        $("#resultBar").hidden = false;
        $("#outInfo").hidden = false;
        $("#outInfo").textContent = infoText;
        $("#resetBtn").hidden = false;
        ED.lastThumb = makeThumb(thumbSource, thumbW, thumbH);
        ED.lastInfo = infoText;
        ED.coins += 5;
        $("#coinCount").textContent = ED.coins;
      }

      /* ----- compare slider ----- */
      let cmpPos = 50, dragging = false;
      function setCompare(p) {
        cmpPos = Math.max(2, Math.min(98, p));
        $("#beforeLayer").style.clipPath = "inset(0 0 0 " + cmpPos + "%)";
        $("#cmpDivider").style.left = cmpPos + "%";
        $("#cmpHandle").style.left = cmpPos + "%";
      }
      function comparePoint(e) {
        const r = $("#compareBox").getBoundingClientRect();
        return (e.clientX - r.left) / r.width * 100;
      }
      $("#compareBox").addEventListener("pointerdown", (e) => {
        if (ED.busy || !ED.img) return;
        if (ED.resultBlob && ED.resultKind === "image") {
          dragging = true;
          $("#compareBox").setPointerCapture(e.pointerId);
          setCompare(comparePoint(e));
        } else if (ED.mode === "removal" && !ED.resultBlob) {
          const r = $("#compareBox").getBoundingClientRect();
          const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
          ED.spots.push({ x, y });
          const d = document.createElement("span");
          d.className = "spotdot";
          const sz = ED.brush * 200;
          d.style.width = sz + "px"; d.style.height = sz + "px";
          d.style.left = x * 100 + "%"; d.style.top = y * 100 + "%";
          spotLayer.appendChild(d);
          updateActionState();
        }
      });
      $("#compareBox").addEventListener("pointermove", (e) => { if (dragging) setCompare(comparePoint(e)); });
      $("#compareBox").addEventListener("pointerup", () => { dragging = false; });
      $("#compareBox").addEventListener("pointercancel", () => { dragging = false; });

      /* ----- canvas helpers ----- */
      function workCanvas(w, h) { const c = document.createElement("canvas"); c.width = w; c.height = h; return c; }
      function colorPass(cv, p) {
        try {
          const t = workCanvas(cv.width, cv.height);
          const tc = t.getContext("2d");
          tc.filter = "saturate(" + p.sat + ") contrast(" + p.con + ") brightness(" + p.bri + ")";
          tc.drawImage(cv, 0, 0);
          cv.getContext("2d").drawImage(t, 0, 0);
        } catch (err) { /* filter unsupported: color step skipped */ }
      }
      function smoothPass(cv, amt) {
        if (amt <= 0) return;
        try {
          const t = workCanvas(cv.width, cv.height);
          const tc = t.getContext("2d");
          tc.filter = "blur(2px)";
          tc.drawImage(cv, 0, 0);
          const c = cv.getContext("2d");
          c.save(); c.globalAlpha = Math.min(.65, amt * .7); c.drawImage(t, 0, 0); c.restore();
        } catch (err) { /* skip */ }
      }
      async function sharpenPass(cv, amount, onp) {
        if (amount <= 0) { onp && onp(1); return; }
        const w = cv.width, h = cv.height, ctx = cv.getContext("2d");
        const src = ctx.getImageData(0, 0, w, h);
        const out = ctx.createImageData(w, h);
        const s = src.data, d = out.data, a = amount, c0 = 1 + 4 * a;
        const rowsPer = Math.max(1, Math.floor(400000 / w));
        for (let y0 = 0; y0 < h; y0 += rowsPer) {
          const y1 = Math.min(h, y0 + rowsPer);
          for (let y = y0; y < y1; y++) {
            const ym = (y > 0 ? y - 1 : 0) * w, yq = (y < h - 1 ? y + 1 : h - 1) * w, yc = y * w;
            for (let x = 0; x < w; x++) {
              const xm = x > 0 ? x - 1 : 0, xp = x < w - 1 ? x + 1 : w - 1;
              const i = (yc + x) * 4, iu = (ym + x) * 4, idn = (yq + x) * 4, il = (yc + xm) * 4, ir = (yc + xp) * 4;
              d[i] = c0 * s[i] - a * (s[iu] + s[idn] + s[il] + s[ir]);
              d[i + 1] = c0 * s[i + 1] - a * (s[iu + 1] + s[idn + 1] + s[il + 1] + s[ir + 1]);
              d[i + 2] = c0 * s[i + 2] - a * (s[iu + 2] + s[idn + 2] + s[il + 2] + s[ir + 2]);
              d[i + 3] = 255;
            }
          }
          onp && onp(y1 / h);
          await tick();
        }
        ctx.putImageData(out, 0, 0);
      }
      function targetDims(w, h) {
        const RES = { hd: 1920, "4k": 3840, "16k": 8192 };
        const longEdge = Math.max(w, h);
        const target = Math.max(longEdge, Math.min(RES[ED.res], 8192));
        const sc = target / longEdge;
        let tw = Math.round(w * sc), th = Math.round(h * sc);
        const MAXP = 12000000;
        if (tw * th > MAXP) { const s2 = Math.sqrt(MAXP / (tw * th)); tw = Math.round(tw * s2); th = Math.round(th * s2); }
        return { w: tw, h: th };
      }

      /* ----- enhance ----- */
      
      // ---- AI cloud backend (Vercel serverless + Replicate). Falls back to on-device ----
      let __cloudAvailable = null;
      async function cloudEnhanceAvailable() {
        if (__cloudAvailable !== null) return __cloudAvailable;
        try {
          const r = await fetch("api/enhance-status", { cache: "no-store" });
          const j = await r.json();
          __cloudAvailable = !!(j && j.configured);
        } catch (e) { __cloudAvailable = false; }
        return __cloudAvailable;
      }
      function loadImageFromBlob(blob) {
        return new Promise((resolve, reject) => {
          const url = URL.createObjectURL(blob);
          const im = new Image();
          im.onload = () => { URL.revokeObjectURL(url); resolve(im); };
          im.onerror = (e) => { URL.revokeObjectURL(url); reject(e); };
          im.src = url;
        });
      }
      async function runEnhanceCloud() {
        ED.busy = true; updateActionState();
        $("#errBox").hidden = true;
        try {
          const scaleMap = { hd: 2, "4k": 4, "16k": 8 };
          const scale = scaleMap[ED.res] || 4;
          const src = ED.img;
          const maxEdge = 1600;
          const sc = Math.min(1, maxEdge / Math.max(src.naturalWidth, src.naturalHeight));
          const w = Math.max(1, Math.round(src.naturalWidth * sc));
          const h = Math.max(1, Math.round(src.naturalHeight * sc));
          const cv = workCanvas(w, h);
          cv.getContext("2d").drawImage(src, 0, 0, w, h);
          const dataUrl = cv.toDataURL("image/jpeg", 0.9);
          setProg(10, "Uploading to AI…", "Sending your photo to the cloud enhancer");
          const r = await fetch("api/enhance", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ image: dataUrl, scale })
          });
          const j = await r.json().catch(() => ({}));
          if (!r.ok || !j.id) throw new Error((j && j.error) || "AI request failed");
          const t0 = Date.now();
          while (Date.now() - t0 < 180000) {
            await new Promise(res => setTimeout(res, 2500));
            const pr = Math.min(90, 15 + (Date.now() - t0) / 180000 * 75);
            setProg(pr, "AI enhancing…", "Real-ESRGAN is rebuilding details (" + ED.res.toUpperCase() + ")");
            const s = await (await fetch("api/enhance-status?id=" + encodeURIComponent(j.id), { cache: "no-store" })).json();
            if (s.status === "succeeded") {
              const out = Array.isArray(s.output) ? s.output[s.output.length - 1] : s.output;
              if (!out) throw new Error("AI returned no image");
              setProg(95, "Downloading result…", "");
              const blob = await (await fetch(out)).blob();
              const im = await loadImageFromBlob(blob);
              setProg(100, "Done!", "");
              finishResult(blob, "image", "AI Enhanced · " + im.naturalWidth + " × " + im.naturalHeight + " · " + fmtSize(blob.size) + " · drag the handle to compare", im, im.naturalWidth, im.naturalHeight);
              toast("AI Enhanced — nice one!");
              ED.busy = false; updateActionState();
              return true;
            }
            if (s.status === "failed" || s.status === "canceled") throw new Error("AI enhancement failed");
          }
          throw new Error("AI timed out");
        } catch (err) {
          $("#progBox").hidden = true;
          ED.busy = false; updateActionState();
          return false; // fall back to on-device enhance
        }
      }

async function runEnhance() {
        if (!ED.img || ED.busy) return;
        try { if (await cloudEnhanceAvailable()) { if (await runEnhanceCloud()) return; } } catch (e) { /* fall through to on-device */ }
        ED.busy = true; updateActionState();
        $("#errBox").hidden = true;
        const p = ED.preset, img = ED.img;
        const dims = targetDims(img.naturalWidth, img.naturalHeight);
        const cv = workCanvas(dims.w, dims.h);
        const ctx = cv.getContext("2d");
        try {
          setProg(8, "Upscaling…", "Rebuilding your photo at " + ED.res.toUpperCase() + " size");
          await tick();
          ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = "high";
          const half = workCanvas(Math.max(1, Math.round(dims.w * .55)), Math.max(1, Math.round(dims.h * .55)));
          half.getContext("2d").drawImage(img, 0, 0, half.width, half.height);
          ctx.drawImage(half, 0, 0, dims.w, dims.h);
          setProg(30, "Removing noise…", "Smoothing grain while keeping edges");
          await tick();
          const smoothAmt = ED.tool && ED.tool.smoothSlider ? $("#smoothRange").value / 100 : p.smooth;
          smoothPass(cv, smoothAmt * ED.strength);
          setProg(48, "Balancing color…", "Fixing light, contrast and saturation");
          await tick();
          colorPass(cv, p);
          setProg(58, "Sharpening details…", "This is the part that takes a moment");
          await sharpenPass(cv, p.sharp * ED.strength * .9, (f) => setProg(58 + f * 38, "Sharpening details…"));
          setProg(100, "Done!", "");
          const blob = await new Promise(r => cv.toBlob(r, "image/jpeg", .92));
          if (!blob) throw new Error("export failed");
          finishResult(blob, "image", "Enhanced · " + dims.w + " × " + dims.h + " · " + fmtSize(blob.size) + " · drag the handle to compare", cv, dims.w, dims.h);
          toast("Enhanced — nice one!");
        } catch (err) {
          $("#progBox").hidden = true;
          showEditorError("Enhancing ran out of memory on this device. Try the HD output size, or a smaller photo.");
        }
        ED.busy = false; updateActionState();
      }

      /* ----- body warp ----- */
      async function runBody() {
        if (!ED.img || ED.busy) return;
        ED.busy = true; updateActionState();
        const img = ED.img, slim = $("#slimRange").value / 100;
        const maxL = 3000, sc = Math.min(1, maxL / Math.max(img.naturalWidth, img.naturalHeight));
        const w = Math.round(img.naturalWidth * sc), h = Math.round(img.naturalHeight * sc);
        setProg(30, "Reshaping…", "Applying the slim warp");
        await tick();
        const cv = workCanvas(w, h), ctx = cv.getContext("2d");
        ctx.drawImage(img, 0, 0, w, h);
        const n = 56, sw = w / n, widths = [], total = { v: 0 };
        for (let i = 0; i < n; i++) {
          const cx = (i + .5) / n;
          const f = 1 - slim * .22 * Math.exp(-Math.pow(cx - .5, 2) / (2 * .16 * .16));
          widths.push(sw * f); total.v += sw * f;
        }
        const fix = w / total.v;
        let dx = 0;
        const src = workCanvas(w, h); src.getContext("2d").drawImage(img, 0, 0, w, h);
        for (let i = 0; i < n; i++) {
          const dw = widths[i] * fix;
          ctx.drawImage(src, i * sw, 0, sw, h, dx, 0, dw + .6, h);
          dx += dw;
        }
        setProg(85, "Finishing…", "");
        const blob = await new Promise(r => cv.toBlob(r, "image/jpeg", .92));
        finishResult(blob, "image", "Body warp applied · " + w + " × " + h + " · " + fmtSize(blob.size), cv, w, h);
        ED.busy = false; updateActionState();
      }

      /* ----- removal ----- */
      async function runRemoval() {
        if (!ED.img || ED.busy || ED.spots.length === 0) return;
        ED.busy = true; updateActionState();
        const img = ED.img;
        const maxL = 3000, sc = Math.min(1, maxL / Math.max(img.naturalWidth, img.naturalHeight));
        const w = Math.round(img.naturalWidth * sc), h = Math.round(img.naturalHeight * sc);
        const cv = workCanvas(w, h), ctx = cv.getContext("2d");
        ctx.drawImage(img, 0, 0, w, h);
        const rBase = ED.brush * Math.min(w, h);
        let i = 0;
        for (const sp of ED.spots) {
          i++;
          setProg(15 + (i / ED.spots.length) * 75, "Patching spot " + i + " of " + ED.spots.length + "…", "Filling with surrounding texture");
          await tick();
          const x = sp.x * w, y = sp.y * h, r = rBase;
          let sy = y - r * 2.4; if (sy - r < 0) sy = y + r * 2.4; if (sy + r > h) sy = y;
          const patch = workCanvas(Math.ceil(r * 2), Math.ceil(r * 2));
          const pc = patch.getContext("2d");
          pc.drawImage(cv, x - r, sy - r, r * 2, r * 2, 0, 0, r * 2, r * 2);
          const small = workCanvas(Math.max(2, Math.ceil(r / 2)), Math.max(2, Math.ceil(r / 2)));
          small.getContext("2d").drawImage(patch, 0, 0, small.width, small.height);
          pc.imageSmoothingEnabled = true; pc.imageSmoothingQuality = "high";
          pc.clearRect(0, 0, patch.width, patch.height);
          pc.drawImage(small, 0, 0, patch.width, patch.height);
          ctx.save();
          ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.clip();
          ctx.drawImage(patch, x - r, y - r);
          ctx.restore();
        }
        const blob = await new Promise(r => cv.toBlob(r, "image/jpeg", .92));
        const url = URL.createObjectURL(blob);
        const nimg = new Image();
        nimg.onload = () => {
          ED.srcURL = url; ED.img = nimg;
          $("#baseImg").src = url;
          $("#fileDims").textContent = w + " × " + h;
          ED.spots = []; spotLayer.innerHTML = "";
          $("#progBox").hidden = true;
          toast("Spots patched. Tap more spots, or Change to finish.");
          ED.busy = false; updateActionState();
        };
        nimg.src = url;
      }

      /* ----- live wallpaper ----- */
      async function runWallpaper() {
        if (!ED.img || ED.busy) return;
        if (typeof MediaRecorder === "undefined" || !HTMLCanvasElement.prototype.captureStream) {
          showEditorError("This browser cannot record video clips. Try Chrome on Android or desktop.");
          return;
        }
        ED.busy = true; updateActionState();
        const img = ED.img;
        const portrait = img.naturalHeight >= img.naturalWidth;
        const W = portrait ? 540 : 960, H = portrait ? 960 : 540;
        const cv = workCanvas(W, H), ctx = cv.getContext("2d");
        const baseScale = Math.max(W / img.naturalWidth, H / img.naturalHeight);
        const stream = cv.captureStream(30);
        let mime = "video/webm;codecs=vp9";
        if (!MediaRecorder.isTypeSupported(mime)) mime = "video/webm";
        const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 2500000 });
        const chunks = [];
        rec.ondataavailable = (e) => { if (e.data.size) chunks.push(e.data); };
        const done = new Promise(r => { rec.onstop = r; });
        setProg(4, "Recording your live wallpaper…", "3-second slow zoom");
        rec.start(200);
        const t0 = performance.now(), DUR = 3000;
        await new Promise(resolve => {
          (function frame(now) {
            const f = Math.min(1, (now - t0) / DUR);
            const s = baseScale * (1 + .16 * f);
            const dw = img.naturalWidth * s, dh = img.naturalHeight * s;
            ctx.fillStyle = "#000"; ctx.fillRect(0, 0, W, H);
            ctx.drawImage(img, (W - dw) / 2, (H - dh) / 2, dw, dh);
            setProg(4 + f * 92, "Recording your live wallpaper…", Math.ceil((1 - f) * 3) + "s left");
            if (f < 1) requestAnimationFrame(frame); else resolve();
          })(t0);
        });
        rec.stop();
        await done;
        const blob = new Blob(chunks, { type: "video/webm" });
        finishResult(blob, "video", "Live wallpaper · 3s video · " + W + " × " + H + " · " + fmtSize(blob.size), img, img.naturalWidth, img.naturalHeight);
        toast("Live wallpaper ready — download to save it.");
        ED.busy = false; updateActionState();
      }

      /* ---------------- collage ---------------- */
      const COL = { layout: "side", imgs: [null, null, null, null], slot: 0 };
      function slotCount() { return COL.layout === "grid" ? 4 : 2; }
      function renderSlots() {
        const n = slotCount();
        $("#collageSlots").innerHTML = "";
        for (let i = 0; i < n; i++) {
          const b = document.createElement("button");
          b.className = "slot tap";
          b.dataset.slot = i;
          b.innerHTML = COL.imgs[i]
            ? '<img src="' + COL.imgs[i].url + '" alt="Collage photo ' + (i + 1) + '" />'
            : '<span class="plus"><svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span>';
          $("#collageSlots").appendChild(b);
        }
      }
      function drawCover(ctx, img, x, y, w, h) {
        const s = Math.max(w / img.naturalWidth, h / img.naturalHeight);
        const dw = img.naturalWidth * s, dh = img.naturalHeight * s;
        ctx.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
      }
      let collageBlob = null, collageThumb = "";
      async function makeCollage() {
        const n = slotCount();
        if (COL.imgs.slice(0, n).some(x => !x)) { toast("Add a photo to every frame first."); return; }
        $("#collageProg").hidden = false;
        await tick();
        let cv;
        if (COL.layout === "side") { cv = workCanvas(1600, 1000); drawCover(cv.getContext("2d"), COL.imgs[0].img, 0, 0, 796, 1000); drawCover(cv.getContext("2d"), COL.imgs[1].img, 804, 0, 796, 1000); }
        else if (COL.layout === "stack") { cv = workCanvas(1000, 1600); drawCover(cv.getContext("2d"), COL.imgs[0].img, 0, 0, 1000, 796); drawCover(cv.getContext("2d"), COL.imgs[1].img, 0, 804, 1000, 796); }
        else { cv = workCanvas(1400, 1400); const ctx = cv.getContext("2d"); drawCover(ctx, COL.imgs[0].img, 0, 0, 696, 696); drawCover(ctx, COL.imgs[1].img, 704, 0, 696, 696); drawCover(ctx, COL.imgs[2].img, 0, 704, 696, 696); drawCover(ctx, COL.imgs[3].img, 704, 704, 696, 696); }
        collageBlob = await new Promise(r => cv.toBlob(r, "image/jpeg", .92));
        collageThumb = makeThumb(cv, cv.width, cv.height);
        const out = $("#collageOut");
        out.src = URL.createObjectURL(collageBlob);
        out.hidden = false;
        $("#collageBar2").hidden = false;
        $("#collageProg").hidden = true;
        toast("Collage ready!");
      }

      /* ---------------- wiring ---------------- */
      function wireSeg(id, cb) {
        const el = document.getElementById(id);
        el.addEventListener("click", (e) => {
          const b = e.target.closest("button"); if (!b) return;
          $$("button", el).forEach(x => x.classList.toggle("on", x === b));
          cb(b);
        });
      }
      document.addEventListener("click", (e) => {
        const tab = e.target.closest("[data-tab]");
        if (tab) { switchTab(tab.dataset.tab); return; }
        const closer = e.target.closest("[data-close-screen]");
        if (closer) { closeScreen(closer); return; }
        const opener = e.target.closest("[data-open-screen]");
        if (opener) { openScreen(opener.dataset.openScreen); return; }
        const ed = e.target.closest("[data-open-editor]");
        if (ed) { openEditor(ed.dataset.openEditor); return; }
        const tool = e.target.closest("[data-tool]");
        if (tool) { $$(".screen").forEach(s => { if (s.id === "screen-alltools") s.hidden = true; }); openEditor(tool.dataset.tool); return; }
        const tplCard = e.target.closest("[data-open-template]");
        if (tplCard) { openTemplate(tplCard.dataset.openTemplate); return; }
        const tplThumb = e.target.closest("[data-template]");
        if (tplThumb) { openTemplate(tplThumb.dataset.template); return; }
        const fav = e.target.closest("[data-fav]");
        if (fav) {
          const id = fav.dataset.fav;
          if (favs.has(id)) { favs.delete(id); toast("Removed from favorites"); } else { favs.add(id); toast("Saved to favorites"); }
          renderTpls(); renderDrafts();
          return;
        }
        const chip = e.target.closest("[data-chip]");
        if (chip) { activeChip = chip.dataset.chip; renderChips(); renderTpls(); return; }
        const sample = e.target.closest("[data-sample]");
        if (sample) { loadImageFromURL(sample.dataset.sample, sample.dataset.sample.split("/").pop()); return; }
        const os = e.target.closest("[data-open-sample]");
        if (os) { openEditor(os.dataset.sampleTool || "quality", { loadURL: "assets/img-09.jpg", loadName: "sm-city-laoag.jpg" }); return; }
        const dr = e.target.closest("[data-draft]");
        if (dr) { openDraft(parseInt(dr.dataset.draft, 10)); return; }
      });

      function openTemplate(id) {
        const t = TPLS.find(x => x.id === id);
        if (!t) return;
        openEditor(t.tool, { preset: t.preset, label: t.name, title: t.name, note: "Template look", loadURL: t.img, loadName: t.id + "-template.jpg" });
        toast("Template loaded — enhance it, or Change to use your own photo.");
      }
      function openDraft(id) {
        const d = drafts.find(x => x.id === id);
        if (!d) return;
        currentDraftId = id;
        $("#draftTitle").textContent = d.name;
        $("#draftImg").src = d.kind === "image" ? URL.createObjectURL(d.blob) : d.thumb;
        $("#draftInfo").textContent = d.info + (d.kind === "video" ? " · video draft — download to watch it" : "");
        openScreen("screen-draft");
      }

      $$(".tabbar button").forEach(b => b.addEventListener("click", () => switchTab(b.dataset.tab)));
      $("#gemBtn").addEventListener("click", () => openScreen("screen-vip"));
      $("#vipStripBtn").addEventListener("click", () => openScreen("screen-vip"));
      $("#coinPill").addEventListener("click", () => openScreen("screen-vip"));
      $("#vipCta").addEventListener("click", () => closeScreen($("#vipCta")));
      $$("#screen-vip .plan").forEach(p => p.addEventListener("click", () => {
        $$("#screen-vip .plan").forEach(x => x.classList.toggle("on", x === p));
      }));
      $("#cloudGoDrafts").addEventListener("click", () => {
        closeScreen($("#cloudGoDrafts"));
        switchTab("me");
        setTimeout(() => $(".drafts-head").scrollIntoView({ behavior: "smooth", block: "start" }), 60);
      });
      $("#clearDraftsBtn").addEventListener("click", () => {
        drafts.length = 0; favs.clear();
        renderDrafts(); renderTpls();
        toast("Drafts and favorites cleared for this session.");
      });

      /* editor wiring */
      const fileInput = $("#fileInput");
      $("#uploadBtn").addEventListener("click", () => fileInput.click());
      $("#dropzone").addEventListener("click", (e) => { if (e.target.id !== "uploadBtn") fileInput.click(); });
      fileInput.addEventListener("change", () => { loadImageFile(fileInput.files[0]); fileInput.value = ""; });
      const dz = $("#dropzone");
      ["dragenter", "dragover"].forEach(ev => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add("drag"); }));
      ["dragleave", "drop"].forEach(ev => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove("drag"); }));
      dz.addEventListener("drop", (e) => { const f = e.dataTransfer.files && e.dataTransfer.files[0]; loadImageFile(f); });
      $("#changePhotoBtn").addEventListener("click", () => fileInput.click());
      $("#resetBtn").addEventListener("click", () => {
        clearResult();
        $("#editorMain").hidden = true;
        $("#editorEmpty").hidden = false;
        ED.img = null;
        updateActionState();
      });
      wireSeg("resSeg", (b) => { ED.res = b.dataset.res; });
      wireSeg("strSeg", (b) => { ED.strength = parseFloat(b.dataset.str); });
      wireSeg("brushSeg", (b) => { ED.brush = parseFloat(b.dataset.brush); $("#brushVal").textContent = b.textContent; });
      $("#smoothRange").addEventListener("input", (e) => { $("#smoothVal").textContent = e.target.value + "%"; });
      $("#slimRange").addEventListener("input", (e) => { $("#slimVal").textContent = e.target.value + "%"; });
      $("#actionBtn").addEventListener("click", () => {
        if (ED.mode === "body") runBody();
        else if (ED.mode === "removal") runRemoval();
        else if (ED.mode === "wallpaper") runWallpaper();
        else runEnhance();
      });
      $("#downloadBtn").addEventListener("click", () => {
        if (!ED.resultBlob) return;
        const ext = ED.resultKind === "video" ? "webm" : "jpg";
        downloadBlob(ED.resultBlob, "picsmooth-" + (ED.tool ? ED.tool.id : "photo") + "-" + Date.now() + "." + ext);
      });
      $("#draftBtn").addEventListener("click", () => {
        if (!ED.resultBlob) return;
        addDraft(ED.label, ED.resultBlob, ED.resultKind, ED.lastThumb, ED.lastInfo);
        $("#draftBtn").textContent = "Saved to Drafts ✓";
        toast("Saved — find it under Me › Drafts.");
      });

      /* draft screen wiring */
      $("#draftDownload").addEventListener("click", () => {
        const d = drafts.find(x => x.id === currentDraftId);
        if (d) downloadBlob(d.blob, "picsmooth-draft-" + d.id + (d.kind === "video" ? ".webm" : ".jpg"));
      });
      $("#draftDelete").addEventListener("click", () => {
        const i = drafts.findIndex(x => x.id === currentDraftId);
        if (i >= 0) drafts.splice(i, 1);
        renderDrafts();
        closeScreen($("#draftDelete"));
        toast("Draft deleted.");
      });

      /* collage wiring */
      const collageInput = $("#collageInput");
      $("#collageSlots").addEventListener("click", (e) => {
        const s = e.target.closest("[data-slot]");
        if (!s) return;
        COL.slot = parseInt(s.dataset.slot, 10);
        collageInput.click();
      });
      collageInput.addEventListener("change", () => {
        const f = collageInput.files[0];
        collageInput.value = "";
        if (!f) return;
        if (!/^image\/(jpeg|png|webp)$/.test(f.type) || f.size > 10 * 1024 * 1024) { toast("Use a JPG or PNG under 10MB."); return; }
        const url = URL.createObjectURL(f);
        const img = new Image();
        img.onload = () => { COL.imgs[COL.slot] = { img, url }; renderSlots(); };
        img.src = url;
      });
      wireSeg("collageSeg", (b) => { COL.layout = b.dataset.layout; renderSlots(); });
      $("#collageMake").addEventListener("click", makeCollage);
      $("#collageDownload").addEventListener("click", () => { if (collageBlob) downloadBlob(collageBlob, "picsmooth-collage-" + Date.now() + ".jpg"); });
      $("#collageDraft").addEventListener("click", () => {
        if (!collageBlob) return;
        addDraft("Collage", collageBlob, "image", collageThumb, "Collage · " + fmtSize(collageBlob.size));
        toast("Saved — find it under Me › Drafts.");
      });

      /* search wiring */
      $("#toolSearch").addEventListener("input", (e) => {
        const q = e.target.value.trim().toLowerCase();
        let any = false;
        $$("#toolsGrid .tool").forEach(el => {
          const show = !q || el.dataset.name.includes(q);
          el.style.display = show ? "" : "none";
          if (show) any = true;
        });
        const nr = $("#toolNoResults");
        if (nr) nr.hidden = any;
      });
      $("#tplSearch").addEventListener("input", renderTpls);

      /* init */
      renderTools();
      renderAllTools();
      renderChips();
      renderTpls();
      renderDrafts();
      renderSlots();
      $("#planYearly").classList.add("on");
